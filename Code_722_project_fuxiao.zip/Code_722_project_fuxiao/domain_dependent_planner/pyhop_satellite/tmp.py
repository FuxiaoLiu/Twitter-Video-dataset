import json
import hgn_pyhop, satellite_domain
from time import process_time

print('')
hgn_pyhop.print_operators()
print('')
hgn_pyhop.print_methods()
state1 = hgn_pyhop.State('state1')


filename1 = './object.txt'
f = open(filename1, "r", encoding="utf-8")
lines = f.read()

datas = lines.split('\n')

tmp_satellite = []
tmp_instruments = []
tmp_modes = []
tmp_directions = []
for data in datas:
    #print(data)
    if len(data) == 0:
        break
    tmp = data[1:].split(' - ')
    #print(tmp)
    if tmp[1] == 'satellite':
        tmp_satellite.append(tmp[0])

    if tmp[1] == 'instrument':
        tmp_instruments.append(tmp[0])

    if tmp[1] == 'mode':
        tmp_modes.append(tmp[0])

    if tmp[1] == 'direction':
        tmp_directions.append(tmp[0])

#object
state1.satellites = {i for i in tmp_satellite}
state1.instruments = {i for i in tmp_instruments}
state1.modes = {i for i in tmp_modes}
state1.directions = {i for i in tmp_directions}

#print(state1.satellites, state1.instruments, state1.modes,  state1.directions)
print(state1.satellites)
print(state1.instruments)
print(state1.modes)
print(state1.directions, '\n')

#init
filename1 = './init.txt'
f = open(filename1, "r", encoding="utf-8")
lines = f.read()

datas = lines.split('\n')

tmp_supports = {}
tmp_power = []
tmp_pointing = {}
tmp_on_board = {}
tmp_calibration_target = {}
for data in datas:
    #print(data)
    tmp = data[2:-1].split(' ')
    #print(tmp)
    if tmp[0] == 'supports':
        tmp_supports[tmp[1]] = tmp[2]

    if tmp[0] == 'power_avail':
        tmp_power.append(tmp[1])

    if tmp[0] == 'pointing':
        tmp_pointing[tmp[1]] = tmp[2]

    if tmp[0] == 'on_board':
        tmp_on_board[tmp[1]] = tmp[2]

    if tmp[0] == 'calibration_target':
        tmp_calibration_target[tmp[1]] = tmp[2]


state1.power_avail = {i:True for i in tmp_power}
state1.pointing = tmp_pointing
state1.on_board = tmp_on_board
state1.supports = tmp_supports
state1.calibration_target = tmp_calibration_target
state1.power_on = {i: False for i in tmp_instruments}
state1.calibrated = {i: False for i in tmp_instruments}
state1.have_image = {i: '' for i in tmp_directions}

print(state1.power_avail)
print(state1.pointing)
print(state1.on_board)
print(state1.supports)
print(state1.calibration_target)
print(state1.power_on)
print(state1.calibrated)
print(state1.have_image, '\n')

#goal

filename1 = './goal.txt'
f = open(filename1, "r", encoding="utf-8")
lines = f.read()

tmp_goal = []
datas = lines.split('\n')
for data in datas:
    tmp = data[2:-1].split(' ')
    print(tmp)
    tmp_goal.append((tmp[0], tmp[1], tmp[2]))

#print(tmp_goal)

t1_start = process_time()
result = hgn_pyhop.pyhop(state1, tmp_goal, verbose=1)
t1_stop = process_time()
print('Time:', t1_stop-t1_start)
print('length of step:', len(result))

