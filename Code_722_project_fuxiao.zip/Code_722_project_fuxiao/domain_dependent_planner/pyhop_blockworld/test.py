from __future__ import print_function
from pyhop import *

import json
filename1 = './data/example25.txt'
f = open(filename1, "r", encoding="utf-8")
lines = f.read()

datas = lines.split('\n')


result = []
for i in range(len(datas)):
    if i % 2 !=0:
        blocks = datas[i].split(' ')[1:]
        result.append(blocks)

init = []
goal = []
block_names = []
for i in range(len(result)):
    tmp3 = []
    tmp4 = []
    j = 0
    for r1 in result[i]:
        j +=1
        tmp3.append(int(r1))
        tmp4.append('block' + str(j))
    if i % 2 == 0:
        init.append(tmp3)
        block_names.append(tmp4)
    if i % 2 != 0:
        goal.append(tmp3)
num_blocks = len(init[0])
on = []
clear = []

for i in range(len(init)):
    tmp1 = []
    tmp2 = []
    for j in range(num_blocks):
        tmp1.append('table')
        tmp2.append('clear')
    on.append(tmp1)
    clear.append(tmp2)


for i in range(len(init)):
    for j in range(len(init[i])):
        if init[i][j] != 0:
            on[i][j] = 'block' + str(init[i][j])
            clear[i][init[i][j]-1] = 'noclear'

on_goal = []
clear_goal = []

for i in range(len(goal)):
    tmp1 = []
    tmp2 = []
    for j in range(num_blocks):
        tmp1.append('table')
        tmp2.append('clear')
    on_goal.append(tmp1)
    clear_goal.append(tmp2)



for i in range(len(goal)):
    for j in range(len(goal[i])):
        if goal[i][j] != 0:
            on_goal[i][j] = 'block' + str(goal[i][j])
            clear_goal[i][goal[i][j]-1] = 'noclear'

#above is reading the txt file

#===============

import blocks_world_operators
print('')
print_operators()

import blocks_world_methods
print('')
print_methods()
from time import process_time


time_avg = 0
num_of_step_avg = 0
for i in range(len(init)):
    init_pos = {}
    init_clear = {}
    goal_pos = {}
    goal_clear = {}
    for j in range(len(init[i])):
        init_pos['block' + str(j+1)] = on[i][j]
        goal_pos['block' + str(j+1)] = on_goal[i][j]
        if clear[i][j] == 'clear':
            init_clear['block' + str(j+1)] = True
        if clear[i][j] == 'noclear':
            init_clear['block' + str(j+1)] = False

        if clear_goal[i][j] == 'clear':
            goal_clear['block' + str(j+1)] = True
        if clear_goal[i][j] == 'noclear':
            goal_clear['block' + str(j+1)] = False

    state1 = State('state1')
    state1.pos = init_pos
    state1.clear = init_clear
    state1.holding = False

    #print_state(state1)
    #print('')
    #print("- Define goal1a:")

    goal1a = Goal('goal1a')
    goal1a.pos = goal_pos
    goal1a.clear = goal_clear
    goal1a.holding = False

    #print_goal(goal1a)
    #print('')

    t1_start = process_time()
    result = pyhop(state1, [('move_blocks', goal1a)], verbose=1)
    t1_stop = process_time()
    print('========================')
    print('example index:', i+1)
    print('Time:', t1_stop - t1_start)
    print('length of step:', len(result))
    print('========================')
    time_avg = time_avg + (t1_stop - t1_start)
    num_of_step_avg = num_of_step_avg + len(result)

print('Average:', time_avg/len(init), num_of_step_avg/len(init))





